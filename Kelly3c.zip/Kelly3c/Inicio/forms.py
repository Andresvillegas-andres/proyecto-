from django import forms
from . models import Equipo


class support(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ['personal', 'usuario', 'asunto', 'prioridad', 'estado']
        widgets = {'personal':forms.Select(attrs={'class': 'form-control'}),
		'usuario':forms.TextInput(attrs={'class': 'form-control','placeholder':'ingrese su Nombre',}),
		'asunto':forms.Select(attrs={'class': 'form-control'}),
		'prioridad':forms.Select(attrs={'class': 'form-control'}),
		'estado': forms.TextInput(attrs={'class': 'form-control','placeholder':'Ingrese un Breve Comentario',}),
		}