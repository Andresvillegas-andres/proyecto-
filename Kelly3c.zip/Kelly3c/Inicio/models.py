from django.db import models

# Create your models here.

class Asunto(models.Model):
	asunto=models.CharField(max_length=50)
	created=models.DateTimeField(auto_now_add=True)
	updated=models.DateTimeField(auto_now_add=True)

	class Meta:
		verbose_name='Asunto'
		verbose_name_plural='Asuntos'
	def __str__(self):
		return self.asunto

class Personal(models.Model):
	personal=models.CharField(max_length=50)
	created=models.DateTimeField(auto_now_add=True)
	updated=models.DateTimeField(auto_now_add=True)

	class Meta:
		verbose_name='Personal'
		verbose_name_plural='Personals'
	def __str__(self):
		return self.personal

class Prioridad(models.Model):
	opcion=models.CharField(max_length=50)
	created=models.DateTimeField(auto_now_add=True)
	updated=models.DateTimeField(auto_now_add=True)

	class Meta:
		verbose_name='Prioridad'
		verbose_name_plural='Prioridades'
	def __str__(self):
		return self.opcion

class Equipo(models.Model):
	personal = models.ForeignKey(Personal, on_delete=models.CASCADE)
	usuario = models.CharField(max_length=500, blank=True)
	asunto = models.ForeignKey(Asunto, on_delete=models.CASCADE)
	estado=models.CharField(max_length=200, blank=True)
	prioridad=models.ForeignKey(Prioridad, on_delete=models.CASCADE)
	created=models.DateTimeField(auto_now_add=True)
	updated=models.DateTimeField(auto_now_add=True)
	class Meta:
		verbose_name = "equipo"
		verbose_name_plural = "equipo"
		ordering = ['id']

	def __str__(self):
		return self.usuario