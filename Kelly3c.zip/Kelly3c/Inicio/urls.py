from django.urls import path, include
from Inicio import views
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.conf.urls.static import static

urlpatterns = [
    path('',login_required(views.con), name="Inicio"),
]
urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)